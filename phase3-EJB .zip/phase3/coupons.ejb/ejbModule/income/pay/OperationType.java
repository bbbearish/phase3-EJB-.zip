package income.pay;

public enum OperationType {
	
	customer_purchase,company_create,company_update;
	

}
